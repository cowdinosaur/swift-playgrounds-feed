import SwiftUI

struct ContentView: View {
    @State var counter = 0
    @State var message = ""
    
    var body: some View {
        VStack {
            Text("\(counter) cookies eaten")
            Button {
                print("Bye bye cookie!!")
                counter += 1
                
                if counter >= 20 {
                    message = "Don't eat too many cookies"
                } else if counter >= 30 {
                    message = "Oh no you're not listening right?"
                } else {
                    message = "You did it!"
                }
            } label: {
                Text("OM NO NOM")
                    .padding()
                    .background(.blue)
                    .foregroundColor(.white)    
            }
            if counter >= 20 {
                Text(message)
            }
        }
    }
}
